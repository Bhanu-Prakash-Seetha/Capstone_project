import React from "react";
import Navbaradmin from "./Navbaradmin";
function Adminwebinar(){
return(
    <div>
        <Navbaradmin/>
        Adminwebinar
    </div>
)
}
 
export default Adminwebinar